//
//  page2.swift
//  assignment 2
//
//  Created by David on 2018/4/29.
//  Copyright © 2018年 david. All rights reserved.
//

import UIKit

var order = ["order 1", "order 2", "order 3"]
var orderDesc = ["order 1 detail", "order 2 detail", "order 3 detail"]
var myIndex = 0

class page2: UITableViewController {
    
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return order.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = order[indexPath.row]
        
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        myIndex = indexPath.row
        performSegue(withIdentifier: "segue", sender: self)
    }
}
