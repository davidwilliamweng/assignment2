//
//  ViewController.swift
//  assignment 2
//
//  Created by David on 2018/4/29.
//  Copyright © 2018年 david. All rights reserved.
//


import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        titleLabel.text = order[myIndex]
        descLabel.text = orderDesc[myIndex]
        
    }
    @IBOutlet weak var back1: UIButton!
    @IBOutlet weak var back2: UIButton!
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}




